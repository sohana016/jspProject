/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.form;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.model.SelectItem;

/**
 *
 * @author Md Yasin Arif
 */
@ManagedBean (name="subjt")
@RequestScoped
public class subject {
//    SelectItem[] sub = new SelectItem[]{
//    new SelectItem("Java","Java"),
//    new SelectItem("PHP","PHP"),
//    new SelectItem("C#","C#")
//        
//    
//    };
//  
//   
//
//    public SelectItem[] getSub() {
//        return sub;
//    }
//
//    public void setSub(SelectItem[] sub) {
//        this.sub = sub;
//    }
    
    
    
    
}
